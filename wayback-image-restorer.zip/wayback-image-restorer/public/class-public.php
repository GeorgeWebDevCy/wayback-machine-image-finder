<?php

declare(strict_types=1);

namespace Wayback_Image_Restorer\Public_;

if (!defined('ABSPATH')) {
    exit;
}

final class Public_
{
    private string $plugin_name;
    private string $version;

    public function __construct()
    {
        $this->plugin_name = 'wayback-image-restorer';
        $this->version = '1.0.2';
    }

    public function enqueue_assets(): void
    {
    }
}
